<?php

include_once __DIR__ . "/src/Service/Router.php";

$router = new Router();
$router->index();